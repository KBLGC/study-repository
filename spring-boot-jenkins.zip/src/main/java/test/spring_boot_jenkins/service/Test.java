package test.spring_boot_jenkins.service;

public class Test {
	 public static void main(String[] args) {
		
	}
}
