package test.spring_boot_jenkins.mapper;

import test.spring_boot_jenkins.entity.User;
import tk.mybatis.mapper.common.Mapper;

public interface UserMapper extends Mapper<User>{

}
